<div class="main-content">
    determinants
</div>