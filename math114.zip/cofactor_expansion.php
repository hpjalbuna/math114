<div class="main-content">
cofactor_expansion
</div>